<footer class="container-fluid footer text-center">
  <div class="col-md-6">
    &copy;<?php echo "" . date("Y") ?> copyright
  </div>
  <div class="col-md-6">
    Developed by Amplify Mindware
  </div>
  <br /> &nbsp;
</footer>