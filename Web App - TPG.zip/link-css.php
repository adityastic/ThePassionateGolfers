<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.7 -->
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="dist/fonts/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="dist/fonts/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
<link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
<!-- Google Font -->
<link rel="stylesheet" href="dist/fonts/source-sans-pro.css">
<!-- DataTable -->
<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
<link rel="stylesheet" href="dist/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="dist/css/rowReorder.dataTables.min.css">
<link rel="stylesheet" href="dist/css/responsive.dataTables.min.css">
<!--JALERT-->
  <link rel="stylesheet" href="css/jAlert.css">
  <link rel="stylesheet" href="css/jquery-confirm.css">