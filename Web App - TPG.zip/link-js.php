<!-- jQuery 3.1.1 -->
<script src="js/jQuery/jquery-3.1.1.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- FastClick 
<script src="plugins/fastclick/fastclick.js"></script>-->
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- DataTable -->
<script src="dist/js/jquery.dataTables.min.js"></script>
<script src="dist/js/dataTables.rowReorder.min.js"></script>
<script src="dist/js/dataTables.responsive.min.js"></script>
<!-- DataTable Call -->
<script src="dist/js/dataTable-call.js"></script>
<!-- jAlert -->

	<script src="js/jAlert.js"></script>
	<script src="js/jAlert-functions.js"></script>
	<script src="js/jquery-confirm.js"></script>

	<link rel="stylesheet" href="css/jAlert.css">
	<link rel="stylesheet" href="css/jquery-confirm.css">

	<!-- jAlert -->